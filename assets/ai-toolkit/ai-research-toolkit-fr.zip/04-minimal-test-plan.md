# Plan de test minimal (liste de contrôle, une demi-journée)

| Test | Comment | Pourquoi | Qui valide |
|---|---|---|---|
| Reproductibilité | Graine fixée, résultats identiques ; empreinte des poids et du jeu de données | Un tiers peut reproduire les résultats | Doctorant et encadrant |
| Robustesse | Validation croisée k-fold ou sous-échantillons | Le modèle n'est pas sur-ajusté à un seul jeu | Doctorant |
| Test de stress | Données extrêmes : pics d'éclairement, manques, anomalies de capteurs | Stabilité hors conditions normales | Encadrant |
| Dérive | nRMSE et NICE sur données récentes contre anciennes, avec seuils | Anticiper la perte de performance | Référent MLOps et qualité |
| Licences | Chaque donnée et code réutilisé respecte sa licence | Conformité juridique | Responsable des données FAIR |
| README et mention IA | Usage de l'IA générative indiqué | Transparence | Doctorant |
| Validation finale | Relecture scientifique et technique | Qualité avant diffusion | Encadrant responsable |

Pour un modèle en service, un **plan de surveillance** ajoute des seuils, par exemple : nRMSE contrôlée chaque mois, alerte au-delà de +0,05 et critique au-delà de +0,10, puis analyse et réapprentissage ; couverture des données contrôlée chaque semaine, alerte sous 95 % ; plus de trois incidents par mois déclenchent un diagnostic urgent.
