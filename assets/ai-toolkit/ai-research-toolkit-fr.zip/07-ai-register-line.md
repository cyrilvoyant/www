# Une ligne du registre IA

| Projet | Modèle | Usage d'IA générative | Statut | Partenaires | Données | Dernière revue |
|---|---|---|---|---|---|---|
| Prévision GHI, thèse 2026 | ELM, MLP | Assistant de code, indiqué dans le README | Recherche seule | Aucun | Données météorologiques publiques | Lancement ; à tout changement de destination |
