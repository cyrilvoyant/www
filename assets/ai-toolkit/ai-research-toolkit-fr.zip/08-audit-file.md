# Contenu d'un dossier prêt pour l'audit

- README avec l'usage de l'IA générative et les licences des données et du code ;
- fiche données (origine, biais, base légale, réutilisation) et fiche modèle (type, données, métriques, limites, supervision humaine, traçabilité Git) ;
- plan de test et ses résultats, validés par l'encadrant ;
- plan de gestion des données avec les six champs IA ;
- journal des versions : versions du modèle, commits Git, évolutions du jeu de données ;
- pour un déploiement à haut risque : plan de surveillance (nRMSE, NICE, dérive, seuils) et procédure d'incident (canal de remontée, responsable nommé, délai de correction).
