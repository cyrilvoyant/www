# README avec la mention d'usage de l'IA

**Projet : MLP, prévision de l'éclairement global horizontal (GHI)** · Auteur : Prénom Nom · Encadrant : Prénom Nom · O.I.E., Mines Paris – PSL

- **Objet** : entraîner un perceptron multicouche pour prévoir le GHI horaire à partir de données météorologiques.
- **Usage de l'IA** : aide ponctuelle d'un assistant d'IA générative (nom et version) pour du code standard et du débogage. Toutes les suggestions ont été revérifiées par l'auteur (tests unitaires, validation par l'encadrant), nom et date.
- **Données** : réseau SIAR (Espagne), 2005–2015 ; normalisation, gestion des manques ; données publiques non personnelles ; licence indiquée.
- **Tests** : fixer la valeur initiale du générateur aléatoire (la graine) pour répéter une simulation ; vérifier des résultats identiques sur des exécutions répétées ; validation croisée (k > 3, où *k* est le nombre de partitions des données) ; test de stress sur les pics d'éclairement et les valeurs manquantes ; dérive suivie par la nRMSE et NICE sur des données récentes. La nRMSE est une racine d'erreur quadratique moyenne normalisée ; NICE compare les erreurs de prévision à celles de la persistance, la référence qui répète la dernière observation disponible. Le choix de normalisation et le protocole d'évaluation doivent accompagner les scores.
- **Réutilisation** : recherche académique ; toute utilisation industrielle doit être validée par le laboratoire.
