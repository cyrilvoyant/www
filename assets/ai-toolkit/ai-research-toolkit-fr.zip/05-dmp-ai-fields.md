# Les six champs IA d'un plan de gestion des données

1. **Base légale** : licence CC BY, convention industrielle ou consentement (RGPD).
2. **Supervision humaine** : qui valide les résultats, quand, à quel niveau (dans, sur ou hors de la boucle).
3. **Transparence IA** : si un contenu ou un code a été produit avec une IA, et comment c'est signalé.
4. **Conditions de réutilisation** : libre, sous licence, ou réservée à un contrat.
5. **Transferts internationaux** : si des données sortent de l'UE (nuage non européen, partenaire étranger) et les garanties.
6. **Analyse d'impact** : AIPD si données personnelles ; FRIA pour certains déploiements publics à haut risque ; sinon, pourquoi aucune ne s'applique.
