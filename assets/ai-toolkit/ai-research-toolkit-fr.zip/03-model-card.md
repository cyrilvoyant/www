# Fiche modèle (moins de deux pages)

| Champ | À renseigner | Exemple (*illustratif*) |
|---|---|---|
| Nom, version | Identifiant unique | MLP_GHI_v1.2 |
| Type | Architecture | MLP, 3 couches de 64 neurones |
| Données | Jeux de données, période, découpage | SIAR (Espagne), 2005–2015, 70/15/15 % |
| Usage prévu | Recherche, simulation ou déploiement | Recherche académique, prévision horaire du GHI |
| Métriques | Contre une référence explicite | nRMSE, nMAE, NICE² par rapport à la persistance |
| Résultats clés | Par station, horizon, saison | Tableau par station |
| Sous-groupes | Résultats par climat ou saison | Moins bon en climat méditerranéen |
| Limites connues | Ce que le modèle ne couvre pas | Pannes de capteurs, forte variabilité nuageuse |
| Supervision humaine | Qui valide les sorties | Encadrant de thèse, relecture du comité IA |
| Traçabilité | Références techniques | Commit Git, modèle archivé avec un DOI |
| Réutilisation | Libre, licence ou contrat | Libre pour la recherche ; usage industriel sous accord |
