# Criblage AIPD et FRIA, deux projets contrastés

Documenter la décision et sa justification : un score numérique ne détermine pas une obligation juridique. **AIPD** : le responsable du traitement apprécie le risque élevé pour les personnes, avec le conseil du DPO lorsqu’il est désigné (CNIL(https://www.cnil.fr/fr/gerer-les-risques)). **FRIA** : vérifier l’usage prévu, la qualification à haut risque et le déployeur au regard de l’article 27(https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-27) ; le point 2 de l’annexe III est exclu de cette obligation spécifique.

- **Prévision pour une thèse à partir de seules données météorologiques** : dans ce scénario, aucun traitement de données personnelles nécessitant une AIPD n’est identifié. Consigner le contexte de recherche et réexaminer l’applicabilité avant un déploiement.
- **Prévision de consommation des foyers pour un gestionnaire de réseau** : examiner les risques des profils de consommation avec le responsable du traitement et le DPO. Le secteur énergétique ne suffit pas à déduire une obligation de FRIA. Documenter l’usage prévu, la catégorie applicable et les responsabilités ; une analyse volontaire reste possible.
