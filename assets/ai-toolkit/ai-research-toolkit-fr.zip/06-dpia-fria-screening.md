# Criblage AIPD et FRIA, deux projets contrastés

Six questions oui/non, notées 0 ou 1. **AIPD** : données personnelles ? base légale nécessaire ? risque pour la vie privée (identifiants, localisation fine, santé, habitudes) ? **FRIA** : organisme public ou usage à haut risque (annexe III) ? risque de discrimination ou d'exclusion ? supervision humaine absente ?

- **Prévision d'éclairement à partir de données météorologiques, pour une thèse** : AIPD 0/3, FRIA 0/3. Données météorologiques seulement, usage académique, validation systématique par l'encadrant : aucune n'est requise, et le criblage est conservé comme preuve qu'elle a été envisagée.
- **Prévision de consommation des foyers déployée par un gestionnaire de réseau** : AIPD 3/3 (les profils de consommation révèlent des habitudes), FRIA 2/3 (infrastructure critique ; risque de favoriser certaines zones ou certains profils), supervision humaine présente. Les deux analyses sont menées conjointement par le laboratoire (fournisseur scientifique) et l'opérateur (déployeur et responsable légal), avec pseudonymisation, supervision humaine, surveillance et dossier prêt pour l'audit.
