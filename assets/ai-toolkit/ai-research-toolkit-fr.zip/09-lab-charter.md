# Une charte de laboratoire d'une page

*En tant que membre du laboratoire, je m'engage à respecter les principes suivants pour l'utilisation et le développement de systèmes d'intelligence artificielle, conformément à l'AI Act et aux principes FAIR.*

1. **IA générative** (assistants conversationnels, assistants de code) : autorisée comme aide à la rédaction, au code et aux figures, avec mention systématique de son usage (rapport, article, README).
2. **Relecture humaine** : tout ce qui est produit avec une IA est vérifié par une personne ; relecture technique et bibliographique avant toute diffusion. L'auteur reste responsable.
3. **Documentation minimale** pour chaque projet : une fiche données, une fiche modèle, un dépôt Git versionné avec un README (plateforme de l'établissement ; les projets peuvent rester privés).
4. **Registre IA** : chaque projet utilisant l'IA y est inscrit ; le passage de la recherche à l'industrie déclenche une réévaluation.
5. **Plan de gestion des données** avec les six champs IA : base légale, supervision humaine, transparence IA, réutilisation, transferts internationaux, analyse d'impact.

*Nom, fonction, date, signature.*
