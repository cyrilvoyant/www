# L'IA dans la recherche : kit de modèles

Neuf modèles remplis, tirés de la page *L'IA dans la recherche : AI Act, charte de laboratoire et boîte à outils* (Cyril Voyant, version 1.2, 24 octobre 2026), https://www.cyrilvoyant.com/fr/ia-dans-la-recherche/ . Ils viennent des modèles du laboratoire O.I.E. ; les valeurs marquées *illustratives* ne sont pas des résultats. Remplacez chaque valeur d'exemple par la vôtre.

Ce n'est pas un avis juridique et cela ne garantit pas la conformité ; pour un projet réel, interrogez le service juridique de votre établissement.

Si vous réutilisez ces modèles, merci de citer la page ci-dessus.
