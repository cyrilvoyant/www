# Fiche données (une page)

| Champ | À renseigner | Exemple |
|---|---|---|
| Nom du jeu de données | Nom utilisé dans le projet | SIAR_GHI_ES_2005_2015 |
| Origine | Fournisseur ou réseau de stations | Réseau SIAR (Espagne) |
| Période, volume | Dates couvertes et taille | 2005–2015, 10 stations, 50 000 enregistrements |
| Variables | Variables principales et unités | GHI (W/m²), température (°C), humidité ( %) |
| Prétraitements | Étapes appliquées | Normalisation min-max, interpolation des manques |
| Qualité | Évaluation rapide | 3 % de valeurs manquantes, capteurs étalonnés |
| Biais connus | Points de vigilance | Répartition géographique non homogène |
| Licence, base légale (RGPD) | Licence de diffusion ou base juridique | CC BY 4.0, données publiques |
| Transferts hors UE | Oui ou non, et garanties | Non (stockage dans l'UE uniquement) |
| Réutilisation | Libre, contrat ou restriction | Libre à des fins académiques |
