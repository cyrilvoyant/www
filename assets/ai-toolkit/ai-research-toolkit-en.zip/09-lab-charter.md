# A one-page laboratory charter

*As a member of the laboratory, I commit to the following principles for using and developing artificial intelligence, in line with the AI Act and the FAIR principles.*

1. **Generative AI** (chat assistants, code assistants) is allowed as an aid for writing, code and figures, and its use is always stated (report, paper, README).
2. **Human review**: everything produced with AI is checked by a person; technical and bibliographic review before any release. The author remains responsible.
3. **Minimal documentation** for every project: a data card, a model card, a versioned Git repository with a README (the institution's platform; projects may stay private).
4. **AI register**: every project using AI is listed; moving from research to industry triggers a new assessment.
5. **Data management plan** with the six AI fields: legal basis, human oversight, AI transparency, reuse, international transfers, impact assessment.

*Name, role, date, signature.*
