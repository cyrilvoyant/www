# The six AI fields of a data management plan

1. **Legal basis**: for personal data, identify the applicable basis under Article 6 GDPR, and Article 9 conditions where relevant. Record copyright licences and reuse agreements separately; they do not replace a GDPR legal basis.
2. **Human oversight**: who validates the results, when, at which level (in, on or outside the loop).
3. **AI transparency**: whether content or code was generated with AI, and how it is stated.
4. **Conditions of reuse**: free, under licence, or reserved to a contract.
5. **International transfers**: whether data leave the EU (non-European cloud, partner abroad) and the safeguards.
6. **Impact assessment**: DPIA where personal-data processing is likely to create a high risk to people; FRIA for some high-risk public deployments; otherwise, why neither applies.
