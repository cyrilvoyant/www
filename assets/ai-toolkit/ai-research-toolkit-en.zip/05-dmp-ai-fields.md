# The six AI fields of a data management plan

1. **Legal basis**: licence CC BY, industrial agreement or consent (GDPR).
2. **Human oversight**: who validates the results, when, at which level (in, on or outside the loop).
3. **AI transparency**: whether content or code was generated with AI, and how it is stated.
4. **Conditions of reuse**: free, under licence, or reserved to a contract.
5. **International transfers**: whether data leave the EU (non-European cloud, partner abroad) and the safeguards.
6. **Impact assessment**: DPIA if personal data; FRIA for some high-risk public deployments; otherwise, why neither applies.
