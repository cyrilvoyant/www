# Data card (one page)

| Field | What to write | Example |
|---|---|---|
| Dataset name | Name used in the project | SIAR_GHI_ES_2005_2015 |
| Origin | Provider or station network | SIAR network (Spain) |
| Period, volume | Dates covered and size | 2005–2015, 10 stations, 50k records |
| Variables | Main variables and units | GHI (W/m²), temperature (°C), humidity (%) |
| Preprocessing | Steps applied | Min-max normalization, gap interpolation |
| Quality | Quick assessment | 3 % missing values, calibrated sensors |
| Known biases | Points of attention | Uneven geographical coverage |
| Licence, legal basis (GDPR) | Licence or legal ground | CC BY 4.0, public data |
| Transfers outside the EU | Yes or no, and safeguards | No (storage in the EU only) |
| Reuse | Free, contract or restricted | Free for academic purposes |
