# README with the AI-use statement

**Project: multilayer perceptron (MLP), global horizontal irradiance (GHI) forecasting** · Author: First Last · Supervisor: First Last · O.I.E., Mines Paris – PSL

- **Purpose**: train a multilayer perceptron to forecast hourly GHI from weather data.
- **Use of AI**: occasional help from a generative AI assistant (name and version) for boilerplate code and debugging. Every suggestion was reviewed by the author (unit tests, validation by the supervisor), name and date.
- **Data**: SIAR network (Spain's agroclimatic information system for irrigation), 2005–2015; normalization, gap handling; public, non-personal data; licence stated.
- **Tests**: fix the random-number generator's starting value (the seed) to repeat a simulation; check identical results on repeated runs; cross-validation (k > 3 folds, where *k* is the number of data partitions); stress test on irradiance peaks and missing values; drift checked with nRMSE and NICE on recent data. nRMSE is a normalised root mean squared error; NICE compares forecast errors with persistence, the reference that repeats the last available observation. The normalisation and evaluation protocol must be stated with the scores.
- **Reuse**: academic research; any industrial use must be agreed with the laboratory.
