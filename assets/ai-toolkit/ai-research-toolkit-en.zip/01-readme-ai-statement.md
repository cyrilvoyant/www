# README with the AI-use statement

**Project: MLP, global horizontal irradiance (GHI) forecasting** · Author: First Last · Supervisor: First Last · O.I.E., Mines Paris – PSL

- **Purpose**: train a multilayer perceptron to forecast hourly GHI from weather data.
- **Use of AI**: occasional help from a generative AI assistant (name and version) for boilerplate code and debugging. Every suggestion was reviewed by the author (unit tests, validation by the supervisor), name and date.
- **Data**: SIAR network (Spain), 2005–2015; normalization, gap handling; public, non-personal data; licence stated.
- **Tests**: fixed seed, identical results on repeated runs; cross-validation (k > 3 folds); stress test on irradiance peaks and missing values; drift checked with nRMSE and NICE on recent data.
- **Reuse**: academic research; any industrial use must be agreed with the laboratory.
