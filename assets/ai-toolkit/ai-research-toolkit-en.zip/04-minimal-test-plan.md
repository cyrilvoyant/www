# Minimal test plan (checklist, half a day)

| Test | How | Why | Who validates |
|---|---|---|---|
| Reproducibility | Fixed seed, identical results; hash of weights and dataset | A third party can reproduce the results | PhD student and supervisor |
| Robustness | k-fold cross-validation or subsamples | The model does not overfit one dataset | PhD student |
| Stress test | Extreme data: irradiance peaks, gaps, sensor anomalies | Stable behavior outside normal conditions | Supervisor |
| Drift | nRMSE and NICE on recent versus older data, with thresholds | Anticipate loss of performance | MLOps and quality referent |
| Licences | Every dataset and code reused respects its licence | Legal compliance | FAIR data steward |
| README and AI statement | Use of generative AI stated | Transparency | PhD student |
| Final review | Scientific and technical reading | Quality before release | Responsible supervisor |

For a model in operation, a **monitoring plan** adds thresholds, for example: nRMSE checked monthly, alert above +0.05 and critical above +0.10, then analysis and retraining; data coverage checked weekly, alert below 95 %; more than three incidents a month triggers an urgent diagnosis.
