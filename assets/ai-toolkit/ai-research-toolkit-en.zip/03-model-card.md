# Model card (under two pages)

| Field | What to write | Example (*illustrative*) |
|---|---|---|
| Name, version | Unique identifier | MLP_GHI_v1.2 |
| Type | Architecture | MLP, 3 layers of 64 neurons |
| Data | Datasets, period, split | SIAR (Spain), 2005–2015, 70/15/15 % |
| Intended use | Research, simulation or deployment | Academic research, hourly GHI forecasting |
| Metrics | Against an explicit reference | nRMSE, nMAE, NICE² against persistence |
| Key results | By station, horizon, season | Table by station |
| Subgroups | Results by climate or season | Weaker in Mediterranean climate |
| Known limits | What the model does not cover | Sensor failures, strong cloud variability |
| Human oversight | Who validates the outputs | Thesis supervisor, AI committee review |
| Traceability | Technical references | Git commit, model archived with a DOI |
| Reuse | Free, licence or contract | Free for research; industrial use under agreement |
