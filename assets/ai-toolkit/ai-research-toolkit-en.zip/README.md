# AI in research: toolkit of templates

Nine filled templates from the page *AI in research: the AI Act, a lab charter and a toolbox for researchers* (Cyril Voyant, version 1.2, 24 October 2026), https://www.cyrilvoyant.com/ai-in-research/ . They come from the O.I.E. laboratory templates; values marked *illustrative* are not results. Replace every example value with your own.

This is not legal advice and does not guarantee compliance; ask your institution's legal service for a real project.

When you reuse these templates, please cite the page above.
