# Content of an audit-ready file

- README with the use of generative AI and the licences of data and code;
- data card (origin, biases, legal basis, reuse) and model card (type, data, metrics, limits, human oversight, Git traceability);
- test plan and its results, validated by the supervisor;
- data management plan with the six AI fields;
- change log: versions of the model, Git commits, changes of the dataset;
- for a high-risk deployment: monitoring plan (nRMSE, NICE, drift, thresholds) and an incident procedure (reporting channel, named person, time to fix).
