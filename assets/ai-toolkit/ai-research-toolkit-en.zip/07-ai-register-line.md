# One line of the AI register

| Project | Model | Use of generative AI | Status | Partners | Data | Last review |
|---|---|---|---|---|---|---|
| GHI forecasting, thesis 2026 | ELM, MLP | Code assistant, stated in README | Research only | None | Public weather data | Project start; on any change of purpose |
