# DPIA and FRIA screening, two contrasting projects

Six yes/no questions, scored 0 or 1. **DPIA**: personal data? legal basis needed? privacy risk (identifiers, fine location, health, habits)? **FRIA**: public body or high-risk use (Annex III)? risk of discrimination or exclusion? human oversight absent?

- **Weather-based irradiance forecasting for a thesis**: DPIA 0/3, FRIA 0/3. Weather data only, academic use, systematic validation by the supervisor: neither is required, and the screening is kept as proof that it was considered.
- **Household load forecasting deployed by a grid operator**: DPIA 3/3 (consumption profiles reveal habits), FRIA 2/3 (critical infrastructure; risk of favoring some areas or profiles), human oversight present. Both assessments are run jointly by the laboratory (scientific supplier) and the operator (deployer and legal owner), with pseudonymization, human oversight, monitoring and an audit-ready file.
