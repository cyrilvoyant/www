# DPIA and FRIA screening, two contrasting projects

Document the decision and its justification; a numerical score does not determine a legal obligation. **DPIA**: the controller assesses whether personal-data processing is likely to pose a high risk, with advice from the DPO where designated (CNIL(https://www.cnil.fr/fr/gerer-les-risques)). **FRIA**: check the intended use, high-risk classification and deployer against Article 27(https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-27); Annex III point 2 is excluded from this specific obligation.

- **Weather-only forecasting for a thesis**: in this stated scenario, no personal-data processing requiring a DPIA is identified. Record the research context and check applicability again before deployment.
- **Household load forecasting for a grid operator**: assess the privacy risks of consumption profiles with the controller and DPO. Do not infer a FRIA obligation from the energy sector alone. Document the intended use, applicable category and responsible parties; an assessment can also be undertaken voluntarily.
